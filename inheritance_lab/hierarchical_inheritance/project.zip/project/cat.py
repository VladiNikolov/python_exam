from project.animal import Animal


class Cat(Animal):

    def meow(self):
        return "meowing..."

# cat = Cat()
# print(cat.meow())
# print(cat.eat())
